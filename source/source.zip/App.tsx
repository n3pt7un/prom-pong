import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Leaderboard from './components/Leaderboard';
import MatchLogger from './components/MatchLogger';
import RecentMatches from './components/RecentMatches';
import CreatePlayerForm from './components/CreatePlayerForm';
import Settings from './components/Settings';
import RacketManager from './components/RacketManager';
import StatsDashboard from './components/StatsDashboard';
import { 
  getLeagueData, recordMatch, createPlayer, createRacket, updatePlayer, 
  deletePlayer, deleteRacket, resetLeagueData 
} from './services/storageService';
import { Player, Match, GameType, EloHistoryEntry, Racket } from './types';
import { Plus, Trash2, Wifi, WifiOff } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('leaderboard');
  const [players, setPlayers] = useState<Player[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [history, setHistory] = useState<EloHistoryEntry[]>([]);
  const [rackets, setRackets] = useState<Racket[]>([]);
  const [showCreatePlayerModal, setShowCreatePlayerModal] = useState(false);
  const [isConnected, setIsConnected] = useState(true);

  // Load data
  const refreshData = async () => {
    try {
      const data = await getLeagueData();
      setPlayers(data.players);
      setMatches(data.matches);
      setHistory(data.history);
      setRackets(data.rackets);
      setIsConnected(true);
    } catch (err) {
      console.error("Connection lost:", err);
      setIsConnected(false);
    }
  };

  useEffect(() => {
    refreshData();
    // Poll for updates every 3 seconds to keep clients in sync
    const interval = setInterval(refreshData, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleMatchSubmit = async (type: GameType, winners: string[], losers: string[], scoreW: number, scoreL: number) => {
    await recordMatch(type, winners, losers, scoreW, scoreL);
    refreshData();
    setActiveTab('leaderboard');
  };

  const handleCreatePlayer = async (name: string, avatar: string, racketId?: string) => {
    await createPlayer(name, avatar, racketId);
    refreshData();
    setShowCreatePlayerModal(false);
  };

  const handleDeletePlayer = async (id: string, name: string) => {
    if (window.confirm(`Delete ${name}? They will be removed from the roster. Historical match records will remain but link to 'Unknown'.`)) {
      await deletePlayer(id);
      refreshData();
    }
  }

  const handleCreateRacket = async (name: string, icon: string, color: string, stats: string) => {
    await createRacket(name, icon, color, stats);
    refreshData();
  };

  const handleDeleteRacket = async (id: string) => {
    await deleteRacket(id);
    refreshData();
  }

  const handleUpdatePlayerRacket = async (playerId: string, racketId: string) => {
    await updatePlayer(playerId, { mainRacketId: racketId });
    refreshData();
  };

  const handleSeasonReset = async () => {
    if (window.confirm("Are you sure? This will clear all match history and reset everyone's Elo to 1200.")) {
      await resetLeagueData('season');
      refreshData();
    }
  };

  const handleFactoryReset = async () => {
    if (window.confirm("WARNING: Restore Demo Data? This deletes everything.")) {
      await resetLeagueData('wipe');
      refreshData();
    }
  }

  const handleStartFresh = async () => {
    if (window.confirm("WARNING: Delete all players and data to start an empty group?")) {
      await resetLeagueData('fresh');
      refreshData();
    }
  }

  const renderContent = () => {
    if (activeTab === 'leaderboard') {
      return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Leaderboard players={players} />
          </div>
          <div className="lg:col-span-1">
             <RecentMatches matches={matches} players={players} />
          </div>
        </div>
      );
    }
    
    if (activeTab === 'log') {
      if (players.length < 2) return <div className="text-center text-gray-500 mt-10">Add at least 2 players to log matches.</div>;
      return <MatchLogger players={players} onSubmit={handleMatchSubmit} />;
    }

    if (activeTab === 'players') {
      return (
        <div className="space-y-6">
           <div className="flex justify-between items-center">
             <h2 className="text-2xl font-display font-bold text-white">ROSTER</h2>
             <button onClick={() => setShowCreatePlayerModal(true)} className="flex items-center gap-2 bg-cyber-pink text-black px-4 py-2 rounded font-bold hover:bg-white transition-colors">
               <Plus size={18} /> Add Player
             </button>
           </div>
           
           {players.length === 0 && (
             <div className="text-center py-10 border border-dashed border-white/10 rounded-xl text-gray-500">
               No agents found. Initialize new player to begin.
             </div>
           )}

           <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
             {players.map(p => (
               <div key={p.id} className="relative glass-panel p-4 rounded-lg flex flex-col items-center gap-2 hover:border-cyber-cyan transition-colors group">
                 <img src={p.avatar} className="w-16 h-16 rounded-full group-hover:scale-110 transition-transform object-cover" />
                 <span className="font-bold text-white text-center truncate w-full">{p.name}</span>
                 
                 {/* Delete Button - Always visible now */}
                 <button 
                   onClick={(e) => { e.stopPropagation(); handleDeletePlayer(p.id, p.name); }}
                   className="absolute top-2 right-2 p-1.5 text-gray-400 bg-black/50 hover:text-red-500 hover:bg-red-500/20 rounded-full transition-colors"
                   title="Delete Player"
                 >
                    <Trash2 size={14} />
                 </button>
               </div>
             ))}
           </div>
           <div className="text-center text-gray-500 text-sm mt-8">
              Go to "Stats" to view detailed profiles and compare players.
           </div>
        </div>
      );
    }

    if (activeTab === 'armory') {
      return <RacketManager rackets={rackets} onCreateRacket={handleCreateRacket} onDeleteRacket={handleDeleteRacket} />
    }

    if (activeTab === 'stats') {
      if (players.length === 0) return <div className="text-center text-gray-500 mt-10">Create a player to see stats.</div>;
      
      return (
        <StatsDashboard 
          players={players} 
          matches={matches} 
          history={history} 
          rackets={rackets} 
          onUpdateRacket={handleUpdatePlayerRacket} 
        />
      );
    }

    if (activeTab === 'settings') {
      return <Settings onResetSeason={handleSeasonReset} onFactoryReset={handleFactoryReset} onStartFresh={handleStartFresh} />;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {!isConnected && (
        <div className="fixed top-0 left-0 w-full bg-red-600 text-white text-center text-xs py-1 z-[100] font-bold flex items-center justify-center gap-2">
           <WifiOff size={12} /> CONNECTION LOST - ATTEMPTING RECONNECT
        </div>
      )}
      {renderContent()}
      
      {showCreatePlayerModal && (
        <CreatePlayerForm 
          rackets={rackets}
          onClose={() => setShowCreatePlayerModal(false)}
          onSubmit={handleCreatePlayer}
        />
      )}
    </Layout>
  );
}

export default App;