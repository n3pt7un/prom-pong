import React, { useState, useEffect } from 'react';
import { Trash2, RefreshCw, AlertTriangle, Save, History, RotateCcw, UserX, Download } from 'lucide-react';
import { getBackups, createBackup, Backup } from '../services/storageService';

interface SettingsProps {
  onResetSeason: () => void;
  onFactoryReset: () => void;
  onStartFresh: () => void;
}

const Settings: React.FC<SettingsProps> = ({ onResetSeason, onFactoryReset, onStartFresh }) => {
  const [backups, setBackups] = useState<Backup[]>([]);
  const [showBackups, setShowBackups] = useState(false);

  useEffect(() => {
    setBackups(getBackups());
  }, []);

  const handleCreateBackup = async () => {
    await createBackup(`Manual Backup ${new Date().toLocaleTimeString()}`);
    setBackups(getBackups());
  }

  const handleDownload = (backup: Backup) => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backup));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `cyberpong_backup_${backup.timestamp}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fadeIn pb-20">
      <div className="flex items-center gap-3 mb-6">
        <Save className="text-cyber-cyan w-8 h-8" />
        <h2 className="text-2xl font-display font-bold text-white">SYSTEM <span className="text-cyber-cyan">SETTINGS</span></h2>
      </div>

      {/* Season Reset */}
      <div className="glass-panel p-6 rounded-xl border-l-4 border-l-cyber-purple">
        <div className="flex flex-col md:flex-row items-start justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <RefreshCw className="text-cyber-purple" size={20} />
              Start New Season
            </h3>
            <p className="text-gray-400 mt-2 text-sm">
              Resets all stats (Elo, W/L, History) to defaults. 
              <span className="text-white font-bold ml-1">Keeps players.</span>
            </p>
          </div>
          <button 
            onClick={onResetSeason}
            className="w-full md:w-auto flex-shrink-0 bg-cyber-purple/10 border border-cyber-purple text-cyber-purple hover:bg-cyber-purple hover:text-white px-4 py-2 rounded font-bold transition-all text-sm flex items-center justify-center gap-2"
          >
            <RefreshCw size={16} /> RESET SEASON
          </button>
        </div>
      </div>

      {/* Start Fresh (No Demo) */}
      <div className="glass-panel p-6 rounded-xl border-l-4 border-l-cyber-yellow">
        <div className="flex flex-col md:flex-row items-start justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <UserX className="text-cyber-yellow" size={20} />
              Start Fresh Group
            </h3>
            <p className="text-gray-400 mt-2 text-sm">
              <span className="text-cyber-yellow font-bold uppercase">Exit Demo Mode.</span> Deletes all players and data. Starts with an empty roster so you can add your own people.
            </p>
          </div>
          <button 
             onClick={onStartFresh}
             className="w-full md:w-auto flex-shrink-0 bg-cyber-yellow/10 border border-cyber-yellow text-cyber-yellow hover:bg-cyber-yellow hover:text-black px-4 py-2 rounded font-bold transition-all text-sm flex items-center justify-center gap-2"
          >
            <UserX size={16} /> CLEAR ROSTER
          </button>
        </div>
      </div>

      {/* Factory Reset */}
      <div className="glass-panel p-6 rounded-xl border-l-4 border-l-red-500">
        <div className="flex flex-col md:flex-row items-start justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <AlertTriangle className="text-red-500" size={20} />
              Factory Reset
            </h3>
            <p className="text-gray-400 mt-2 text-sm">
              Wipes everything and <span className="text-white font-bold">restores the demo data</span> (Neo, Trinity, etc).
            </p>
          </div>
          <button 
             onClick={onFactoryReset}
             className="w-full md:w-auto flex-shrink-0 bg-red-500/10 border border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-4 py-2 rounded font-bold transition-all text-sm flex items-center justify-center gap-2"
          >
            <Trash2 size={16} /> RESTORE DEMO
          </button>
        </div>
      </div>
      
      {/* Backups Section */}
      <div className="pt-8 border-t border-white/10">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => setShowBackups(!showBackups)}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <History size={20} />
            <span className="font-bold">Client-Side Backups</span>
            <span className="text-xs bg-white/10 px-2 py-0.5 rounded-full">{backups.length}</span>
          </button>

          <button onClick={handleCreateBackup} className="text-xs bg-white/5 border border-white/20 px-2 py-1 rounded text-white hover:bg-white/10">
            + Create Backup
          </button>
        </div>

        {showBackups && (
          <div className="mt-4 space-y-3 animate-slideUp">
            {backups.length === 0 && <div className="text-gray-500 italic text-sm">No backups found.</div>}
            {backups.map(b => (
              <div key={b.id} className="glass-panel p-4 rounded-lg flex items-center justify-between border-l-2 border-l-gray-500">
                <div>
                  <div className="font-bold text-white text-sm">{b.label}</div>
                  <div className="text-xs text-gray-500 font-mono">
                    {new Date(b.timestamp).toLocaleString()} • {b.data.players.length} Players • {b.data.matches.length} Matches
                  </div>
                </div>
                <div className="flex gap-2">
                    <button 
                    onClick={() => handleDownload(b)}
                    className="bg-white/5 hover:bg-cyber-yellow hover:text-black text-cyber-yellow border border-cyber-yellow/30 px-3 py-1 rounded text-xs font-bold transition-colors flex items-center gap-1"
                    title="Download JSON"
                    >
                    <Download size={12} /> SAVE
                    </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="text-center text-xs text-gray-600 font-mono mt-12">
        CyberPong System v2.0 • Server Synced • Polling Interval: 3s
      </div>
    </div>
  );
};

export default Settings;