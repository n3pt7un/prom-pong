import React from 'react';
import { Trophy, Activity, PlusCircle, Users, Settings, Sword } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  return (
    <div className="min-h-screen bg-cyber-bg text-gray-200 font-sans selection:bg-cyber-cyan selection:text-black">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-cyber-purple/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-cyber-cyan/10 blur-[120px] rounded-full" />
      </div>

      <nav className="fixed bottom-0 md:top-0 md:bottom-auto w-full z-50 glass-panel border-t md:border-b md:border-t-0 border-white/10 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="hidden md:flex items-center gap-2">
            <Trophy className="text-cyber-cyan w-8 h-8" />
            <span className="font-display font-bold text-2xl tracking-wider text-white">
              CYBER<span className="text-cyber-cyan">PONG</span>
            </span>
          </div>

          <div className="flex w-full md:w-auto justify-around md:gap-4 lg:gap-8 overflow-x-auto">
            <NavButton 
              icon={<Trophy size={20} />} 
              label="Rankings" 
              active={activeTab === 'leaderboard'} 
              onClick={() => onTabChange('leaderboard')} 
            />
            <NavButton 
              icon={<PlusCircle size={20} />} 
              label="Log Match" 
              active={activeTab === 'log'} 
              onClick={() => onTabChange('log')} 
            />
            <NavButton 
              icon={<Users size={20} />} 
              label="Players" 
              active={activeTab === 'players'} 
              onClick={() => onTabChange('players')} 
            />
             <NavButton 
              icon={<Sword size={20} />} 
              label="Armory" 
              active={activeTab === 'armory'} 
              onClick={() => onTabChange('armory')} 
            />
             <NavButton 
              icon={<Activity size={20} />} 
              label="Stats" 
              active={activeTab === 'stats'} 
              onClick={() => onTabChange('stats')} 
            />
             <NavButton 
              icon={<Settings size={20} />} 
              label="Settings" 
              active={activeTab === 'settings'} 
              onClick={() => onTabChange('settings')} 
            />
          </div>
        </div>
      </nav>

      <main className="relative z-10 max-w-7xl mx-auto px-4 pb-24 pt-8 md:pt-24 md:pb-12">
        {children}
      </main>
    </div>
  );
};

const NavButton = ({ icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={`flex flex-col md:flex-row items-center gap-2 px-3 lg:px-4 py-2 rounded-lg transition-all duration-300 flex-shrink-0 ${
      active 
        ? 'text-cyber-cyan bg-cyber-cyan/10 shadow-[0_0_15px_rgba(0,243,255,0.2)]' 
        : 'text-gray-400 hover:text-white hover:bg-white/5'
    }`}
  >
    {icon}
    <span className="text-xs md:text-sm font-bold tracking-wide">{label}</span>
  </button>
);

export default Layout;