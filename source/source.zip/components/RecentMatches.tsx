import React from 'react';
import { Match, Player } from '../types';

// Simple time ago helper function
const timeAgo = (dateStr: string) => {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
};

interface RecentMatchesProps {
  matches: Match[];
  players: Player[];
}

const RecentMatches: React.FC<RecentMatchesProps> = ({ matches, players }) => {
  const getPlayerName = (id: string) => players.find(p => p.id === id)?.name || 'Unknown';

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-display font-bold text-white mb-4 border-l-4 border-cyber-pink pl-3">
        RECENT <span className="text-cyber-pink">ACTIVITY</span>
      </h3>
      
      <div className="grid gap-3">
        {/* Display up to 15 matches as requested */}
        {matches.slice(0, 15).map(match => (
          <div key={match.id} className="glass-panel p-4 rounded-lg flex items-center justify-between border-l-2 border-l-cyber-cyan hover:translate-x-1 transition-transform">
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${match.type === 'singles' ? 'bg-cyber-cyan' : 'bg-cyber-pink'}`}></span>
                {match.type} • {timeAgo(match.timestamp)}
              </span>
              <div className="flex items-center gap-2 text-sm md:text-base">
                <span className="font-bold text-white">
                  {match.winners.map(id => getPlayerName(id)).join(' & ')}
                </span>
                <span className="text-cyber-cyan font-mono font-bold mx-1">
                   {match.scoreWinner} - {match.scoreLoser}
                </span>
                <span className="text-gray-400">
                  {match.losers.map(id => getPlayerName(id)).join(' & ')}
                </span>
              </div>
            </div>
            
            <div className="text-right">
              <span className="inline-block bg-cyber-cyan/10 text-cyber-cyan text-xs font-mono font-bold px-2 py-1 rounded border border-cyber-cyan/30">
                +{match.eloChange}
              </span>
            </div>
          </div>
        ))}
        {matches.length === 0 && (
          <div className="text-gray-500 text-center py-8 italic border border-dashed border-white/10 rounded-lg">
            No recent activity.<br/>Log a match to start the feed.
          </div>
        )}
      </div>
    </div>
  );
};

export default RecentMatches;