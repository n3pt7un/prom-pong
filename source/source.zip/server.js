import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Storage } from '@google-cloud/storage';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 8080;
const DB_FILE = path.join(__dirname, 'db.json');
const GCS_BUCKET = process.env.GCS_BUCKET; 

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Debug Middleware to log requests
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    console.log(`[API] ${req.method} ${req.path}`);
  }
  next();
});

// Static files (frontend)
app.use(express.static(path.join(__dirname, 'dist')));

// Initialize Google Cloud Storage
let storage = null;
let bucket = null;
if (GCS_BUCKET) {
  console.log(`☁️ Running in Cloud Mode with Bucket: ${GCS_BUCKET}`);
  storage = new Storage();
  bucket = storage.bucket(GCS_BUCKET);
} else {
  console.log('💻 Running in Local Mode (Local Filesystem)');
}

// --- ELO LOGIC ---
const K_FACTOR = 32;
const INITIAL_ELO = 1200;

const getExpectedScore = (ratingA, ratingB) => 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
const calculateNewRating = (currentRating, actualScore, expectedScore) => Math.round(currentRating + K_FACTOR * (actualScore - expectedScore));
const calculateMatchDelta = (winnerElo, loserElo) => {
  const expectedWinner = getExpectedScore(winnerElo, loserElo);
  const newWinnerElo = calculateNewRating(winnerElo, 1, expectedWinner);
  return newWinnerElo - winnerElo;
};

// --- DATA STORE ---
let db = {
  players: [],
  matches: [],
  history: [],
  rackets: [],
  backups: []
};

const seedData = () => {
  db.rackets = [
    { id: 'r1', name: 'Neon Striker', icon: 'Zap', color: '#fcee0a', stats: 'Speed' },
    { id: 'r2', name: 'Cyber Wall', icon: 'Shield', color: '#00f3ff', stats: 'Defense' },
    { id: 'r3', name: 'Void Smasher', icon: 'Target', color: '#ff00ff', stats: 'Power' },
  ];
  db.players = [
    { id: '1', name: 'Neo', avatar: "https://picsum.photos/id/64/200/200", eloSingles: 1450, eloDoubles: 1200, wins: 15, losses: 2, streak: 5, joinedAt: new Date().toISOString(), mainRacketId: 'r1' },
    { id: '2', name: 'Trinity', avatar: "https://picsum.photos/id/65/200/200", eloSingles: 1380, eloDoubles: 1250, wins: 12, losses: 5, streak: 2, joinedAt: new Date().toISOString(), mainRacketId: 'r2' },
  ];
  db.matches = [];
  db.history = [];
  db.backups = [];
};

// --- PERSISTENCE ---
const loadDB = async () => {
  try {
    if (bucket) {
      const file = bucket.file('db.json');
      const [exists] = await file.exists();
      if (exists) {
        const [contents] = await file.download();
        db = { ...db, ...JSON.parse(contents.toString()) };
        console.log("✅ Database loaded from Cloud Storage");
      } else {
        seedData();
        await saveDB();
      }
    } else {
      if (fs.existsSync(DB_FILE)) {
        db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) };
        if (db.players.length === 0) seedData();
        console.log("✅ Database loaded from local disk");
      } else {
        seedData();
        await saveDB();
      }
    }
  } catch (err) {
    console.error("❌ Error loading DB:", err);
    seedData();
  }
};

const saveDB = async () => {
  try {
    const data = JSON.stringify(db, null, 2);
    if (bucket) {
      await bucket.file('db.json').save(data, { contentType: 'application/json', resumable: false });
    } else {
      fs.writeFileSync(DB_FILE, data);
    }
  } catch (err) {
    console.error("❌ Error saving DB:", err);
  }
};

// --- API ROUTES ---
app.get('/api/state', (req, res) => res.json(db));

app.post('/api/players', async (req, res) => {
  const newPlayer = {
    id: Date.now().toString(),
    ...req.body,
    eloSingles: INITIAL_ELO,
    eloDoubles: INITIAL_ELO,
    wins: 0, losses: 0, streak: 0,
    joinedAt: new Date().toISOString()
  };
  db.players.push(newPlayer);
  await saveDB();
  res.json(newPlayer);
});

app.put('/api/players/:id', async (req, res) => {
  const idx = db.players.findIndex(p => p.id === req.params.id);
  if (idx !== -1) {
    db.players[idx] = { ...db.players[idx], ...req.body };
    await saveDB();
    res.json(db.players[idx]);
  } else {
    res.status(404).json({ error: 'Player not found' });
  }
});

app.delete('/api/players/:id', async (req, res) => {
  db.players = db.players.filter(p => p.id !== req.params.id);
  await saveDB();
  res.json({ success: true });
});

app.post('/api/rackets', async (req, res) => {
  const newRacket = { id: Date.now().toString(), ...req.body };
  db.rackets.push(newRacket);
  await saveDB();
  res.json(newRacket);
});

app.delete('/api/rackets/:id', async (req, res) => {
  db.rackets = db.rackets.filter(r => r.id !== req.params.id);
  db.players = db.players.map(p => p.mainRacketId === req.params.id ? { ...p, mainRacketId: undefined } : p);
  await saveDB();
  res.json({ success: true });
});

app.post('/api/matches', async (req, res) => {
  const { type, winners, losers, scoreWinner, scoreLoser } = req.body;
  const timestamp = new Date().toISOString();
  
  const getP = (id) => db.players.find(p => p.id === id);
  let wElo = 0, lElo = 0;
  
  if (type === 'singles') {
    wElo = getP(winners[0]).eloSingles;
    lElo = getP(losers[0]).eloSingles;
  } else {
    wElo = (getP(winners[0]).eloDoubles + getP(winners[1]).eloDoubles) / 2;
    lElo = (getP(losers[0]).eloDoubles + getP(losers[1]).eloDoubles) / 2;
  }
  
  const delta = calculateMatchDelta(wElo, lElo);
  const historyEntries = [];

  db.players = db.players.map(p => {
    if (winners.includes(p.id)) {
      const newElo = type === 'singles' ? p.eloSingles + delta : p.eloDoubles + delta;
      historyEntries.push({ playerId: p.id, matchId: timestamp, newElo, timestamp, gameType: type });
      return { ...p, eloSingles: type === 'singles' ? newElo : p.eloSingles, eloDoubles: type === 'doubles' ? newElo : p.eloDoubles, wins: p.wins + 1, streak: p.streak >= 0 ? p.streak + 1 : 1 };
    }
    if (losers.includes(p.id)) {
      const newElo = type === 'singles' ? p.eloSingles - delta : p.eloDoubles - delta;
      historyEntries.push({ playerId: p.id, matchId: timestamp, newElo, timestamp, gameType: type });
      return { ...p, eloSingles: type === 'singles' ? newElo : p.eloSingles, eloDoubles: type === 'doubles' ? newElo : p.eloDoubles, losses: p.losses + 1, streak: p.streak <= 0 ? p.streak - 1 : -1 };
    }
    return p;
  });

  db.history.push(...historyEntries);
  const newMatch = { id: Date.now().toString(), type, winners, losers, scoreWinner, scoreLoser, timestamp, eloChange: delta };
  db.matches.unshift(newMatch);
  await saveDB();
  res.json(newMatch);
});

app.post('/api/reset', async (req, res) => {
  if (req.body.mode === 'season') {
    db.players = db.players.map(p => ({ ...p, eloSingles: INITIAL_ELO, eloDoubles: INITIAL_ELO, wins: 0, losses: 0, streak: 0 }));
    db.matches = []; db.history = [];
  } else if (req.body.mode === 'fresh') {
    db.players = []; db.matches = []; db.history = []; db.rackets = [];
  } else {
    seedData();
  }
  await saveDB();
  res.json({ success: true });
});

// Catch-all
app.get('*', (req, res) => {
  const distIndex = path.join(__dirname, 'dist', 'index.html');
  if (fs.existsSync(distIndex)) {
    res.sendFile(distIndex);
  } else {
    // Return simple text for API 404s to avoid "File not found" default confusion
    res.status(404).send('CyberPong Backend: 404 Not Found. If testing in dev, ensure server.js is running.');
  }
});

// Start Server
loadDB().then(() => {
  // Bind to 0.0.0.0 to ensure Docker/Vite proxy can find us
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on port ${PORT}`);
  });
});