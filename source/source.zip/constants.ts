export const K_FACTOR = 32;
export const INITIAL_ELO = 1200;

export const RANKS = [
  { threshold: 0, name: 'NOOB', color: 'text-gray-400' },
  { threshold: 1200, name: 'PADDLER', color: 'text-blue-400' },
  { threshold: 1400, name: 'HUSTLER', color: 'text-purple-400' },
  { threshold: 1600, name: 'MASTER', color: 'text-pink-400' },
  { threshold: 2000, name: 'GOD OF SPIN', color: 'text-yellow-400' },
];

export const AVATARS = [
  "https://picsum.photos/id/64/200/200",
  "https://picsum.photos/id/65/200/200",
  "https://picsum.photos/id/177/200/200",
  "https://picsum.photos/id/91/200/200",
  "https://picsum.photos/id/129/200/200",
  "https://picsum.photos/id/237/200/200",
  "https://picsum.photos/id/338/200/200",
  "https://picsum.photos/id/433/200/200",
  "https://picsum.photos/id/551/200/200",
  "https://picsum.photos/id/669/200/200"
];