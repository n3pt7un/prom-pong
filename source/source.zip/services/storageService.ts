import { Player, Match, EloHistoryEntry, GameType, Racket } from '../types';

export interface LeagueState {
  players: Player[];
  matches: Match[];
  history: EloHistoryEntry[];
  rackets: Racket[];
}

export interface Backup {
  id: string;
  timestamp: string;
  label: string;
  data: LeagueState;
}

const API_URL = '/api';

// --- API Client ---

export const getLeagueData = async (): Promise<LeagueState> => {
  try {
    const res = await fetch(`${API_URL}/state`);
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Server returned ${res.status}: ${text}`);
    }
    return await res.json();
  } catch (err) {
    console.error("API Fetch Error:", err);
    throw err;
  }
};

export const createPlayer = async (name: string, avatar: string, mainRacketId?: string) => {
  const res = await fetch(`${API_URL}/players`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, avatar, mainRacketId })
  });
  return res.json();
};

export const updatePlayer = async (playerId: string, updates: Partial<Player>) => {
  const res = await fetch(`${API_URL}/players/${playerId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  return res.json();
};

export const deletePlayer = async (playerId: string) => {
  await fetch(`${API_URL}/players/${playerId}`, { method: 'DELETE' });
};

export const createRacket = async (name: string, icon: string, color: string, stats: string) => {
  const res = await fetch(`${API_URL}/rackets`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, icon, color, stats })
  });
  return res.json();
};

export const deleteRacket = async (racketId: string) => {
  await fetch(`${API_URL}/rackets/${racketId}`, { method: 'DELETE' });
};

export const recordMatch = async (
  type: GameType,
  winnerIds: string[],
  loserIds: string[],
  scoreWinner: number,
  scoreLoser: number
) => {
  const res = await fetch(`${API_URL}/matches`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type, winners: winnerIds, losers: loserIds, scoreWinner, scoreLoser })
  });
  return res.json();
};

export const resetLeagueData = async (mode: 'season' | 'wipe' | 'fresh') => {
  await fetch(`${API_URL}/reset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mode })
  });
};

// --- Client-Side Backup (Still kept local for now, or can be moved to server) ---
const STORAGE_KEYS = { BACKUPS: 'cyberpong_backups' };

export const getBackups = (): Backup[] => {
  const stored = localStorage.getItem(STORAGE_KEYS.BACKUPS);
  return stored ? JSON.parse(stored) : [];
};

export const createBackup = async (label: string = 'Auto-Backup') => {
  const state = await getLeagueData();
  const backups = getBackups();
  const newBackup: Backup = {
    id: Date.now().toString(),
    timestamp: new Date().toISOString(),
    label,
    data: state
  };
  const updatedBackups = [newBackup, ...backups].slice(0, 5);
  localStorage.setItem(STORAGE_KEYS.BACKUPS, JSON.stringify(updatedBackups));
  return newBackup;
};

// Note: Restore now needs to push data to server, but for simplicity
// we will just keep backups as read-only or manual JSON download in this version
// as 'Restoring' a server state complex to implement safely without full overwrites.
export const restoreBackup = async (backupId: string) => {
  console.warn("Restore not fully supported in synced mode yet.");
};